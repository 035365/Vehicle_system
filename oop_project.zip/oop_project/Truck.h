#pragma once
#include"Vehicle.h"
#include<iostream>
using namespace std;

class Truck :public Vehicle
{
public:
	//constructors

	// 1)DEFAULT CONSTRUCTOR
	Truck();

	// 2)PARAMETRIZED CONSTRUCTOR
	Truck(const double, const char*, bool, const char*, const char*, const int, const int, const char*);

	// 3)COPY CONSTRUCTOR
	Truck(const Truck&);

	//GETTER/SETTER OF CONTAINER SIZE
	double getContainerSize()const;
	void setContainerSize(const double);

	//GETTER/SETTER OF CATEGORY
	char* getCategory()const;
	void setCategory(const char*);

	//GETTER/SETTER OF FOUR WHEEL DRIVE
	bool getFourWheelDrive();
	void setFourWheelDrive(bool);

	//GETTER OF NO OF TRUCKS
	static int getNoOfTrucks();

	//OPERATOR
	const Truck& operator=(const Truck&);

	//OTHER FUNCTIONS
	void read(istream&);
	void display()const;
	void checkType();

	//DESTRUCTOR
	~Truck();

private:
	double containerSize;
	char* category;
	bool fourWheelDrive;
	static int noOfTrucks;
};
//OTHER OPERATORS
ostream& operator<<(ostream&, Truck&);
istream& operator>>(istream&, Truck&);

//Truck.cpp
int Truck::noOfTrucks = 0;

//DEFAULT CONSTRUCTOR
Truck::Truck()
{
	containerSize = 0;
	category = new char[20];
	fourWheelDrive = false;
	noOfTrucks++;
}

//PARAMETRIZED CONSTRUCTOR
Truck::Truck(const double cs, const char* ct, bool f, const char* cn, const char* c, const int n, const int p, const char* t) :Vehicle(cn, c, n, p, t)
{
	containerSize = cs;
	category = copy(ct);
	fourWheelDrive = f;
	noOfTrucks++;
}

//COPY CONSTRUCTOR
Truck::Truck(const Truck& t) :Vehicle(t)
{
	containerSize = t.containerSize;
	category = copy(t.category);
	fourWheelDrive = t.fourWheelDrive;
}

//GETTER/SETTER OF CONTAINER SIZE
double Truck::getContainerSize()const
{
	return containerSize;
}
void Truck::setContainerSize(const double cs)
{
	containerSize = cs;
}

//GETTER/SETTER OF CATEGORY
char* Truck::getCategory()const
{
	return copy(category);
}
void Truck::setCategory(const char* ct)
{
	category = copy(ct);
}

//GETTER/SETTER OF FOUR WHEEL DRIVE
bool Truck::getFourWheelDrive()
{
	if (this->fourWheelDrive)
	{
		return true;
	}
	else
	{
		return false;
	}
}
void Truck::setFourWheelDrive(bool f)
{
	fourWheelDrive = f;
}

//GETTER OF NO OF TRUCKS
int Truck::getNoOfTrucks()
{
	return noOfTrucks;
}

//OPERATOR
const Truck& Truck::operator=(const Truck& t)
{
	if (this != &t)
	{
		//VEHICLE ATTRIBUTES
		setCompanyName(t.getCompanyName());
		setColor(t.getColor());
		setNumberOfWheels(t.getNumberOfWheels());
		setPowerCC(t.getPowerCC());
		setTypeOfVehicle(t.getTypeOfVehicle());

		//TRUCK ATTRIBUTES
		containerSize = t.containerSize;
		category = copy(t.category);
		fourWheelDrive = t.fourWheelDrive;
	}

	return *this;
}

//OTHER FUNCTIONS
void Truck::read(istream& rd)
{
	Vehicle::read();
	int c;
	while (1)
	{
		cout << "ENTER NUMBER OF WHEELS OF TRUCK : ";
		do
		{
			rd >> c;
			if (c == 4 || c == 6)
			{
				setNumberOfWheels(c);
			}
			else
			{
				cout << "ENTERD WHEELS ARE NOT EQUAL TO 4 OR 6 TAKING NUMBER OF WHEELS AGAIN : ";
			}
		} while (c != 4 && c != 6);
		cout << endl;

		cout << "ENTER POWERCC OF TRUCK : ";
		do
		{
			rd >> c;
			if (c <= 3000)
			{
				setPowerCC(c);
			}
			else
			{
				cout << "ENTERED POWER IS NOT LESS NOR EQUAL TO 3000 TAKING POWERCC AGAIN : ";
			}
		} while (c > 3000);
		cout << endl;

		cout << "ENTER SIZE OF CONTAINER : ";
		do
		{
			rd >> containerSize;
			if (containerSize <= 90)
			{
				break;
			}
			else
			{
				cout << "CONTAINER SIZE IS NOT LESS NOR EQUAL TO 90 TAKIN CONTAINER SIZE AGAIN : ";
			}
		} while (containerSize > 90);
		cout << endl;

		cout << "ENTER CATEGORY OF TRUCK (DOUBLE-CABIN/SINGLE-CABIN) : ";
		rd >> category;
		cout << endl;

		cout << "IF TRUCK IS FOUR WHEEL DRIVE OR NOT " << endl;
		cout << "ENTER TRUE(1) OR FALSE(0) : ";
		rd >> fourWheelDrive;
		cout << endl;
		break;
	}
}

void Truck::display()const
{
	Vehicle::display();
	cout << "CONTAINER SIZE OF TRUCK : " << containerSize << endl;
	cout << "CATEGORY OF TRUCK : " << category << endl;
	cout << "FOUR WHEEL DRIVE : ";
	if (fourWheelDrive == 1)
	{
		cout << "YES " << endl;
	}
	else
	{
		cout << "NO " << endl;
	}
	cout << "--------------------------------------------------------------------------------------------------------" << endl;
}

void Truck::checkType()
{
	char c[20] = { "Truck" };
	if (getNumberOfWheels() == 4 && fourWheelDrive == true)
	{
		setTypeOfVehicle(c);
	}
	else if (getNumberOfWheels() == 6)
	{
		setTypeOfVehicle(c);
	}
	else
	{
		cout << "NO SUCH TYPE " << endl;
	}
}

//DESTRUCTOR
Truck::~Truck()
{
	Vehicle::~Vehicle();
	containerSize = 0;
	delete[] category;
	category = nullptr;
	fourWheelDrive = false;
}

//OTHER OPERATORS
ostream& operator<<(ostream& wr, Truck& t)
{
	t.display();
	return wr;
}

istream& operator>>(istream& rd, Truck& t)
{
	t.read(rd);
	return rd;
}