#pragma once
#include"Vehicle.h"
#include"Bike.h"
#include"Car.h"
#include"Truck.h"
#include<iostream>
#include<fstream>
using namespace std;

class BilalMotors
{
public:
	//constructors

	// 1)DEFAULT CONSTRUCTOR
	BilalMotors();

	// 2)COPY CONSTRUCTOR
	BilalMotors(const BilalMotors&);

	//GETTER/SETTER OF SIZE
	const int getSize()const;
	void setSize(int);

	//OPERATORS
	const BilalMotors& operator=(const BilalMotors&);
	const Vehicle* operator[](int)const;
	Vehicle* operator[](int);

	//OTHER FUNCTIONS
	void addVehicle();
	void searchVehicle(char*);
	bool saveData(const char*)const;
	
	//DESTRUCTOR
	~BilalMotors();

private:
	Vehicle** vehicles;
	int size;
};

//BilalMotors.cpp

//DEFAULT CONSTRUCTOR
BilalMotors::BilalMotors()
{
	size = 0;
	vehicles = new Vehicle * [20];
}

//COPY CONSTRUCTOR
BilalMotors::BilalMotors(const BilalMotors& bm)
{
	size = bm.size;
	vehicles = bm.vehicles;
}

//GETTER/SETTER OF SIZE
const int BilalMotors::getSize()const
{
	return this->size;
}
void BilalMotors::setSize(int s)
{
	size = s;
}

//OPERATORS
const BilalMotors& BilalMotors::operator=(const BilalMotors& bm)
{
	if (this != &bm)
	{
		size = bm.size;
		vehicles = bm.vehicles;
	}

	return *this;
}

const Vehicle* BilalMotors::operator[](int index)const
{
	if (index >= 0 && index < 20)
	{
		return this->vehicles[index];
	}
	else
	{
		return this->vehicles[0];
	}
}

Vehicle* BilalMotors::operator[](int index)
{
	if (index >= 0 && index < 20)
	{
		return this->vehicles[index];
	}
	else
	{
		return this->vehicles[0];
	}
}

//OTHER FUNCTIONS
void BilalMotors::searchVehicle(char* c)
{
	int j = 0;
	int count = 0;

	for (int i = 0; i < size; i++)
	{
		if (strcmp(vehicles[i]->getTypeOfVehicle(), c) == 0) 
		{
			count = i;
			j = 1;

			if (j == 1)
			{
				cout << "VEHICLE SEARCHED BY TYPE : " << endl;
				cout << "------------------------" << endl;
				cout << "VEHICLE NUMBER : " << i + 1 << endl;
				vehicles[i]->display();

			}

			else
			{
				cout << "VEHICLE NOT FOUND : " << endl;
			}
		}
	}
	cout << endl;

}

void BilalMotors::addVehicle()
{
	char c;
	char* ch = new char[20];

	while (1)
	{
		cout << "PRESS B OR b FOR BIKE" << endl;
		cout << "PRESS C OR c FOR CAR" << endl;
		cout << "PRESS T OR t FOR TRUCK" << endl;
		cout << "PRESS $ FOR MAIN MENU" << endl;
		cout << endl;

		cout << "ENTER CHOICE : ";
		cin >> c;
		cout << endl;

		if (c == 'b' || c == 'B') 
		{
			Bike* B = new Bike[1];
			B->read(cin);
			B->checkType();

			this->vehicles[this->size++] = B;
			cout << "VEHICLE BIKE ADDED SUCCESSFULLY " << endl;
			cout << endl;
		}
		
		else if (c == 'c' || c == 'C')
		{
			Car* C = new Car[1];
			C->read(cin);
			C->checkType();

			this->vehicles[this->size++] = C;
			cout << "VEHICLE CAR ADDED SUCCESSFULLY " << endl;
			cout << endl;
		}

		else if (c == 't' || c == 'T') 
		{
			Truck* T = new Truck[1];
			T->read(cin);
			T->checkType();

			this->vehicles[this->size++] = T;
			cout << "VEHICLE TRUCK ADDED SUCCESSFULLY " << endl;
			cout << endl;
		}

		else if (c == '$') 
		{
			break;
		}

		else
		{
			cout << "TYPED CHOICE IS NOT VALID TAKING CHOICE AGAIN FROM THE FOLLOWING : " << endl;
			cout << endl;
		}
	}
}

bool BilalMotors::saveData(const char* filename)const
{
	ofstream fout;
	fout.open(filename);
	if (fout.is_open())
	{
		fout << "VEHICLE INFORMATION " << endl;
		fout << "------------------------" << endl;
		fout << "NUMBER OF BIKES : " << Bike::getNoOfBikes() << endl;
		fout << "NUMBER OF CARS : " << Car::getNoOfCars() << endl;
		fout << "NUMBER OF TRUCKS : " << Truck::getNoOfTrucks() << endl;
		fout << endl;

		fout << "COMPANY NAME		TYPE		COLOR		POWERCC" << endl;
		fout << "-----------------------------------------------------------------" << endl;
		for (int i = 0; i < size; i++)
		{
			fout << vehicles[i]->getCompanyName() << "			" << vehicles[i]->getTypeOfVehicle() << "		" << vehicles[i]->getColor() << "		" << vehicles[i]->getPowerCC() << endl;
		}

		return true;
	}

	else 
	{
		return false;
	}

	fout.close();
}

//DESTRUCTOR
BilalMotors::~BilalMotors()
{
	size = 0;
	delete[] vehicles;
	vehicles = 0;
}