#pragma once
#include"Vehicle.h"
#include<iostream>
using namespace std;

class Bike:public Vehicle
{
public:
	//constructors

	// 1)DEFAULT CONSTRUCTOR
	Bike();

	// 2)PARAMETRIZED CONSTRUCTOR
	Bike(const double, bool, bool, const char*, const char*, const int, const int, const char*);

	// 3)COPY CONSTRUCTOR
	Bike(const Bike&);

	//GETTER/SETTER OF HEIGHT
	double getHeight()const;
	void setHeight(const double);

	//GETTER/SETTER OF SELF START
	bool getSelfStart()const;
	void setSelfStart(bool);

	//GETTER/SETTER OF DISC BRAKE
	bool getDiscBrake()const;
	void setDiscBrake(bool);

	//GETTER OF NUMBER OF BIKES
	static int getNoOfBikes();

	//OPERATOR
	const Bike& operator=(const Bike&);

	//OTHER FUNCTIONS
	void display()const;
	void read(istream&);
	void checkType();
	
	//DESTRUCTOR
	~Bike();

private:
	double height;
	bool selfStart;
	bool discBrake;
	static int noOfBikes;
};
//OTHER OPERATORS
ostream& operator<<(ostream&, Bike&);
istream& operator>>(istream&, Bike&);

//Bike.cpp
int Bike::noOfBikes = 0;

//DEFAULT CONSTRUCTOR
Bike::Bike()
{
	height = 0;
	selfStart = false;
	discBrake = false;
	noOfBikes++;
}

//PARAMETRIZED CONSTRUCTOR
Bike::Bike(const double h, bool s, bool d, const char* cn, const char* c, const int n, const int p, const char* t) :Vehicle(cn, c, n, p, t)
{
	height = h;
	selfStart = s;
	discBrake = d;
	noOfBikes++;
}

//COPY CONSTRUCTOR
Bike::Bike(const Bike& b) :Vehicle(b)
{
	height = b.height;
	selfStart = b.selfStart;
	discBrake = b.discBrake;
}

//GETTER/SETTER OF HEIGHT
double Bike::getHeight()const
{
	return height;
}
void Bike::setHeight(const double h)
{
	height = h;
}

//GETTER/SETTER OF SELF START
bool Bike::getSelfStart()const
{
	if (this->selfStart == 1)
	{
		return true;
	}
	else
	{
		return false;
	}
}
void Bike::setSelfStart(bool s)
{
	selfStart = s;
}

//GETTER/SETTER OF DISC BRAKE
bool Bike::getDiscBrake()const
{
	if (this->discBrake)
	{
		return true;
	}
	else
	{
		return false;
	}
}
void Bike::setDiscBrake(bool d)
{
	discBrake = d;
}

//GETTER OF NUMBER OF BIKES
int Bike::getNoOfBikes()
{
	return noOfBikes;
}

//OPERATOR
const Bike& Bike::operator=(const Bike& b)
{
	if (this != &b)
	{
		//VEHICLE ATTRIBUTES
		setCompanyName(b.getCompanyName());
		setColor(b.getColor());
		setNumberOfWheels(b.getNumberOfWheels());
		setPowerCC(b.getPowerCC());
		setTypeOfVehicle(b.getTypeOfVehicle());

		//BIKE ATTRIBUTES
		height = b.height;
		selfStart = b.selfStart;
		discBrake = b.discBrake;
	}

	return *this;
}

//OTHER FUNCTIONS
void Bike::read(istream& rd)
{
	Vehicle::read();
	int c;
	while (1)
	{
		cout << "ENTER NUMBER OF WHEELS OF BIKE : ";
		do
		{
			rd >> c;
			if (c == 2)
			{
				setNumberOfWheels(c);
			}
			else
			{
				cout << "BIKE HAS ONLY 2 WHEELS TAKING NUMBER OF WHEELS AGAIN : ";
			}
		} while (c != 2);
		cout << endl;

		cout << "ENTER POWERCC OF BIKE : ";
		do
		{
			rd >> c;
			if (c <= 150)
			{
				setPowerCC(c);
			}
			else
			{
				cout << "ENTERED POWER IS NOT LESS NOR EQUAL TO 150 TAKING POWERCC AGAIN : ";
			}
		} while (c > 150);
		cout << endl;

		cout << "ENTER HEIGHT OF BIKE : ";
		do
		{
			rd >> height;
			if (height <= 80)
			{
				break;
			}
			else
			{
				cout << "HEIGHT IS NOT LESS NOR EQUAL TO 80 TAKING HEIGHT AGAIN : ";
			}
		} while (c > 80);
		cout << endl;

		cout << "IF BIKE IS SELF START OR NOT ?" << endl;
		cout << "ENTER TRUE(1) OR FALSE(0) : ";
		rd >> selfStart;
		cout << endl;

		cout << "IF BIKE HAVE DISC BRAKE OR NOT ?" << endl;
		cout << "ENTER (1) = TRUE OR (0) = FALSE : " ;
		rd >> discBrake;
		cout << endl;
		break;
	}
}

void Bike::display()const
{
	Vehicle::display();
	cout << "HEIGHT OF BIKE : " << this->height << endl;
	cout << "SELF START : ";
	if (selfStart == 1)
	{
		cout << "YES " << endl;
	}
	else
	{
		cout << "NO " << endl;
	}
	cout << "DISC BRAKE : ";
	if (discBrake == 1)
	{
		cout << "YES" << endl;
	}
	else
	{
		cout << "NO" << endl;
	}
	cout << "--------------------------------------------------------------------------------------------------------" << endl;
}

void Bike::checkType()
{
	
	char c[20] = { "Bike" };
	if (getNumberOfWheels() == 2)
	{
		setTypeOfVehicle(c);
	}
	else
	{
		cout << "NO SUCH TYPE " << endl;
	}
}

//DESTRUCTOR
Bike::~Bike()
{
	Vehicle::~Vehicle();
	height = 0;
	selfStart = false;
	discBrake = false;
}

//OTHER OPERATORS
ostream& operator<<(ostream& wr, Bike& b)
{
	b.display();
	return wr;
}

istream& operator>>(istream& rd, Bike& b)
{
	b.read(rd);
	return rd;
}