#pragma once
#include"Vehicle.h"
#include<iostream>
using namespace std;

class Car:public Vehicle
{
public:
	//constructors

	// 1)DEFAULT CONSTRUCTOR
	Car();

	// 2)PARAMETRIZED CONSTRUCTOR
	Car(const int, const char*, const int, const char*, const char*, const int, const int, const char*);

	// 3)COPY CONSTRUCTOR
	Car(const Car&);

	//GETTER/SETTER OF NUMBER OF DOORS
	int getNoOfDoors()const;
	void setNoOfDoors(const int);

	//GETTER/SETTER OF TRANSMISSION
	char* getTransmission()const;
	void setTransmission(const char*);

	//GETTER/SETTER OF NUMBER OF SEATS
	int getNoOfSeats()const;
	void setNoOfSeats(const int);

	//GETTER OF NO OF CARS
	static int getNoOfCars();

	//OPERATOR
	const Car& operator=(const Car&);

	//OTHER FUNCTIONS
	void display()const;
	void read(istream&);
	void checkType();

	//DESTRUCTOR
	~Car();

private:
	int noOfDoors;
	char* transmission;
	int noOfSeats;
	static int noOfCars;
};
//OTHER OPERATORS
ostream& operator<<(ostream&, Car&);
istream& operator>>(istream&, Car&);

//Car.cpp
int Car::noOfCars = 0;

//DEFAULT CONSTRUCTOR
Car::Car()
{
	noOfDoors = 0;
	transmission = new char[20];
	noOfSeats = 0;
	noOfCars++;
}

//PARAMETRIZED CONSTRUCTOR
Car::Car(const int nd, const char* t, const int ns, const char* cn, const char* c, const int n, const int p, const char* tv) :Vehicle(cn, c, n, p, tv)
{
	noOfDoors = nd;
	transmission = copy(t);
	noOfSeats = ns;
	noOfCars++;
}

//COPY CONSTRUCTOR
Car::Car(const Car& c) :Vehicle(c)
{
	noOfDoors = c.noOfDoors;
	transmission = copy(c.transmission);
	noOfSeats = c.noOfSeats;
}

//GETTER/SETTER OF NUMBER OF DOORS
int Car::getNoOfDoors()const
{
	return noOfDoors;
}
void Car::setNoOfDoors(const int nd)
{
	noOfDoors = nd;
}

//GETTER/SETTER OF TRANSMISSION
char* Car::getTransmission()const
{
	return transmission;
}
void Car::setTransmission(const char* t)
{
	transmission = copy(t);
}

//GETTER/SETTER OF NUMBER OF SEATS
int Car::getNoOfSeats()const
{
	return noOfSeats;
}
void Car::setNoOfSeats(const int ns)
{
	noOfSeats = ns;
}

//GETTER OF NO OF CARS
int Car::getNoOfCars()
{
	return noOfCars;
}

//OPERATOR
const Car& Car::operator=(const Car& c)
{
	if (this != &c)
	{
		//VEHICLE ATTRIBUTES
		setCompanyName(c.getCompanyName());
		setColor(c.getColor());
		setNumberOfWheels(c.getNumberOfWheels());
		setPowerCC(c.getPowerCC());
		setTypeOfVehicle(c.getTypeOfVehicle());

		//CAR ATTRIBUTES
		noOfDoors = c.noOfDoors;
		transmission = copy(c.transmission);
		noOfSeats = c.noOfSeats;
	}

	return *this;
}

//OTHER FUNCTIONS
void Car::read(istream& rd)
{
	Vehicle::read();
	int c;
	while (1)
	{
		cout << "ENTER NUMBER OF WHEELS OF CAR : ";
		do
		{
			rd >> c;
			if (c == 4)
			{
				setNumberOfWheels(c);
			}
			else
			{
				cout << "CAR HAS 4 WHEELS TAKING NUMBER OF WHEELS AGAIN : ";
			}
		} while (c != 4);
		cout << endl;

		cout << "ENTER POWERCC OF CAR : ";
		do
		{
			rd >> c;
			if (c <= 4500)
			{
				setPowerCC(c);
			}
			else
			{
				cout << "ENTERED POWER IS NOT LESS NOR EQUAL TO 4500 TAKING POWERCC AGAIN : ";
			}
		} while (c > 4500);
		cout << endl;

		cout << "ENTER NUMBER OF DOORS OF CAR : ";
		do
		{
			rd >> noOfDoors;
			if (noOfDoors == 4 || noOfDoors == 2)
			{
				break;
			}
			else
			{
				cout << "ENTERED NUMBER OF DOORS ARE NOT EQUAL TO 4 OR 2 TAKING DOORS AGAIN : ";
			}
		} while (noOfDoors != 4 && noOfDoors != 2);
		cout << endl;

		cout << "ENTER TRANSMISSION (AUTOMATIC/MANUAL) : ";
		rd >> transmission;
		cout << endl;

		cout << "ENTER NUMBER OF SEATS : ";
		do
		{
			rd >> noOfSeats;
			if (noOfSeats == 2 || noOfSeats == 5)
			{
				break;
			}
			else
			{
				cout << "ENTERED NUMBER OF SEATS ARE NOT EQUAL TO 5 OR 2 TAKING SEATS AGAIN : ";
			}
		} while (noOfSeats != 5 && noOfSeats != 2);
		cout << endl;
		break;
	}
}

void Car::display()const
{
	Vehicle::display();
	cout << "NUMBER OF DOORS IN CAR : " << noOfDoors << endl;
	cout << "TRANSMISSION OF CAR : " << transmission << endl;
	cout << "NUMBER OF SEATS IN CAR : " << noOfSeats << endl;
	cout << "--------------------------------------------------------------------------------------------------------" << endl;
}

void Car::checkType()
{
	char c[20] = { "Car" };
	if (getNumberOfWheels() == 4)
	{
		setTypeOfVehicle(c);
	}
	else
	{
		cout << "NO SUCH TYPE" << endl;
	}
}

//DESTRUCTOR
Car::~Car()
{
	Vehicle::~Vehicle();
	noOfDoors = 0;
	delete[] transmission;
	transmission = nullptr;
	noOfSeats = 0;
}

//OTHER OPERATORS
ostream& operator<<(ostream& wr, Car& c)
{
	c.display();
	return wr;
}

istream& operator>>(istream& rd, Car& c)
{
	c.read(rd);
	return rd;
}