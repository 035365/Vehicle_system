#pragma once
#include<iostream>
#include<string>
using namespace std;

char* copy(const char* p)
{
	int s = strlen(p);
	char* np = new char[s + 1];
	for (int i = 0; i < s; i++)
	{
		np[i] = p[i];
	}
	np[s] = '\0';
	return np;
}

class Vehicle
{
public:
	//constructors

	// 1)DEFAULT CONSTRUCTOR
	Vehicle();

	// 2)PARAMETRIZED CONSTRUCTOR
	Vehicle(const char*, const char*, const int, const int, const char*);

	// 3)COPY CONSTRUCTOR
	Vehicle(const Vehicle&);

	//GETTER/SETTER OF COMPANY NAME
	char* getCompanyName()const;
	void setCompanyName(const char*);

	//GETTER/SETTER OF COLOR
	char* getColor()const;
	void setColor(const char*);

	//GETTER/SETTER OF NUMBER OF WHEELS
	int getNumberOfWheels()const;
	void setNumberOfWheels(const int);

	//GETTER/SETTER OF POWERCC
	int getPowerCC()const;
	void setPowerCC(const int);

	//GETTER/SETTER OF TYPE OF VEHICLE
	char* getTypeOfVehicle()const;
	void setTypeOfVehicle(const char*);

	//OPERATOR
	const Vehicle& operator=(const Vehicle&);

	//OTHER FUNCTIONS
	virtual void checkType() = 0;
	virtual void display()const;
	virtual void read();

	//DESTRUCTOR
	~Vehicle();

private:
	char* companyName;
	char* color;
	int numberOfWheels;
	int powerCC;
	char* typeOfVehicle;
};

//Vehicle.cpp

//constructors

//DEFAULT CONSTRUCTOR
Vehicle::Vehicle()
{
	companyName = new char[20];
	color = new char[20];
	numberOfWheels = 0;
	powerCC = 0;
	typeOfVehicle = new char[20];
}

//PARAMETRIZED CONSTRUCTOR
Vehicle::Vehicle(const char* cn, const char* c, const int n, const int p, const char* t)
{
	companyName = copy(cn);
	color = copy(c);
	numberOfWheels = n;
	powerCC = p;
	typeOfVehicle = copy(t);
}

//COPY CONSTRUCTOR
Vehicle::Vehicle(const Vehicle& v)
{
	companyName = copy(v.companyName);
	color = copy(v.color);
	numberOfWheels = v.numberOfWheels;
	powerCC = v.powerCC;
	typeOfVehicle = copy(v.typeOfVehicle);
}

//GETTER/SETTER OF COMPANY NAME
char* Vehicle::getCompanyName()const
{
	return copy(companyName);
}
void Vehicle::setCompanyName(const char* cn)
{
	companyName = copy(cn);
}

//GETTER/SETTER OF COLOR
char* Vehicle::getColor()const
{
	return copy(color);
}
void Vehicle::setColor(const char* c)
{
	color = copy(c);
}

//GETTER/SETTER OF NUMBER OF WHEELS
int Vehicle::getNumberOfWheels()const
{
	return numberOfWheels;
}
void Vehicle::setNumberOfWheels(const int n)
{
	numberOfWheels = n;
}

//GETTER/SETTER OF POWER CC
int Vehicle::getPowerCC()const
{
	return powerCC;
}
void Vehicle::setPowerCC(const int p)
{
	powerCC = p;
}

//GETTER/SETTER OF TYPE OF VEHICLE
char* Vehicle::getTypeOfVehicle()const
{
	return copy(typeOfVehicle);
}
void Vehicle::setTypeOfVehicle(const char* t)
{
	typeOfVehicle = copy(t);
}

//OPERATOR
const Vehicle& Vehicle::operator=(const Vehicle& v)
{
	if (this != &v)
	{
		companyName = copy(v.companyName);
		color = copy(v.color);
		numberOfWheels = v.numberOfWheels;
		powerCC = v.powerCC;
		typeOfVehicle = copy(v.typeOfVehicle);
	}

	return *this;
}

//OTHER FUNCTIONS
void Vehicle::display()const
{
	cout << "--------------------------------------------------------------------------------------------------------" << endl;
	cout << "TYPE OF VEHICLE : " << typeOfVehicle << endl;
	cout << "NAME OF COMAPNY : " << companyName << endl;
	cout << "COLOR OF VEHICLE : " << color << endl;
	cout << "NUMBER OF WHEELS : " << numberOfWheels << endl;
	cout << "POWER CC : " << powerCC << endl;
}

void Vehicle::read()
{
	cout << "ENTER TYPE OF VEHICLE : ";
	cin >> typeOfVehicle;
	cout << endl;

	cout << "ENTER COMPANY NAME OF VEHICLE : ";
	cin >> companyName;
	cout << endl;

	cout << "ENTER COLOR OF VEHICLE : ";
	cin >> color;
	cout << endl;
}
//DESTRUCTOR
Vehicle::~Vehicle()
{
	delete[]companyName;
	companyName = nullptr;
	delete[]color;
	color = nullptr;
	delete[]typeOfVehicle;
	typeOfVehicle = nullptr;
	numberOfWheels = 0;
	powerCC = 0;
}